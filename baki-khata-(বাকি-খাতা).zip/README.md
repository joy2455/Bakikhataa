# Baki Khata

A simple and efficient customer debt management application.

## Features

- **Customer Management:** Add, edit, and delete customers.
- **Transaction Tracking:** Record debts and payments for each customer.
- **Multi-language Support:** Available in English and Bengali.
- **Dark Mode:** Smooth transition between light and dark themes.
- **PDF Export:** Generate and download customer statements and transaction reports.
- **Local Storage:** All data is saved locally on your device.

## Tech Stack

- **React:** UI library.
- **TypeScript:** Type safety.
- **Tailwind CSS:** Styling.
- **Lucide React:** Icons.
- **jsPDF:** PDF generation.
- **Vite:** Build tool.

## Getting Started

1.  **Install dependencies:**
    ```bash
    npm install
    ```

2.  **Start the development server:**
    ```bash
    npm run dev
    ```

3.  **Build for production:**
    ```bash
    npm run build
    ```

## License

MIT
