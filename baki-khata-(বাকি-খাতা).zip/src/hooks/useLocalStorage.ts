import { useState, useEffect } from 'react';
import { Customer, AppSettings, Language } from '../types';

const STORAGE_KEYS = {
  CUSTOMERS: 'baki_khata_customers',
  SETTINGS: 'baki_khata_settings',
};

export function useLocalStorage() {
  const [customers, setCustomers] = useState<Customer[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CUSTOMERS);
    return saved ? JSON.parse(saved) : [];
  });

  const [settings, setSettings] = useState<AppSettings>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (saved) return JSON.parse(saved);
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    return { language: 'bn', darkMode: prefersDark };
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(customers));
  }, [customers]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    if (settings.darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [settings]);

  const addCustomer = (name: string, address: string) => {
    const newCustomer: Customer = {
      id: crypto.randomUUID(),
      name,
      address,
      transactions: [],
      createdAt: new Date().toISOString(),
    };
    setCustomers(prev => [...prev, newCustomer]);
  };

  const updateCustomer = (id: string, name: string, address: string) => {
    setCustomers(prev => prev.map(c => c.id === id ? { ...c, name, address } : c));
  };

  const deleteCustomer = (id: string) => {
    setCustomers(prev => prev.filter(c => c.id !== id));
  };

  const addTransaction = (customerId: string, amount: number, description: string, type: 'debt' | 'payment') => {
    setCustomers(prev => prev.map(c => {
      if (c.id === customerId) {
        const newTransaction = {
          id: crypto.randomUUID(),
          amount,
          description,
          date: new Date().toISOString(),
          type,
        };
        return { ...c, transactions: [newTransaction, ...c.transactions] };
      }
      return c;
    }));
  };

  const updateTransaction = (customerId: string, transactionId: string, amount: number, description: string) => {
    setCustomers(prev => prev.map(c => {
      if (c.id === customerId) {
        return {
          ...c,
          transactions: c.transactions.map(t => t.id === transactionId ? { ...t, amount, description } : t)
        };
      }
      return c;
    }));
  };

  const deleteTransaction = (customerId: string, transactionId: string) => {
    setCustomers(prev => prev.map(c => {
      if (c.id === customerId) {
        return {
          ...c,
          transactions: c.transactions.filter(t => t.id !== transactionId)
        };
      }
      return c;
    }));
  };

  const toggleLanguage = () => {
    setSettings(prev => ({ ...prev, language: prev.language === 'en' ? 'bn' : 'en' }));
  };

  const toggleDarkMode = () => {
    setSettings(prev => ({ ...prev, darkMode: !prev.darkMode }));
  };

  return {
    customers,
    settings,
    addCustomer,
    updateCustomer,
    deleteCustomer,
    addTransaction,
    updateTransaction,
    deleteTransaction,
    toggleLanguage,
    toggleDarkMode,
  };
}
