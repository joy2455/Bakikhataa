export type Language = 'en' | 'bn';

export interface Transaction {
  id: string;
  amount: number;
  description: string;
  date: string; // ISO string
  type: 'debt' | 'payment';
}

export interface Customer {
  id: string;
  name: string;
  address: string;
  transactions: Transaction[];
  createdAt: string;
}

export interface AppSettings {
  language: Language;
  darkMode: boolean;
}

export const TRANSLATIONS = {
  en: {
    appName: 'Baki Khata',
    totalDebt: 'Total Outstanding',
    addCustomer: 'Add Customer',
    customerName: 'Customer Name',
    address: 'Address',
    save: 'Save',
    cancel: 'Cancel',
    edit: 'Edit',
    delete: 'Delete',
    search: 'Search Customers...',
    noCustomers: 'No customers found.',
    total: 'Total',
    addTransaction: 'Add Transaction',
    amount: 'Amount',
    description: 'Description',
    date: 'Date',
    history: 'Transaction History',
    exportPdf: 'Export PDF',
    settings: 'Settings',
    language: 'Language',
    darkMode: 'Dark Mode',
    confirmDelete: 'Are you sure you want to delete?',
    back: 'Back',
    newDebt: 'New Debt',
    newPayment: 'New Payment',
    customerDetails: 'Customer Details',
    allTransactions: 'All Transactions',
    statement: 'Statement',
    sl: 'SL',
    startDate: 'Start Date',
    endDate: 'End Date',
    generateReport: 'Generate Report',
    allTime: 'All Time',
    customRange: 'Custom Range',
    balance: 'Balance',
  },
  bn: {
    appName: 'বাকি খাতা',
    totalDebt: 'মোট পাওনা',
    addCustomer: 'কাস্টমার যোগ করুন',
    customerName: 'কাস্টমারের নাম',
    address: 'ঠিকানা',
    save: 'সেভ করুন',
    cancel: 'বাতিল',
    edit: 'এডিট',
    delete: 'ডিলিট',
    search: 'কাস্টমার খুঁজুন...',
    noCustomers: 'কোনো কাস্টমার পাওয়া যায়নি।',
    total: 'মোট',
    addTransaction: 'লেনদেন যোগ করুন',
    amount: 'টাকার পরিমাণ',
    description: 'বিবরণ',
    date: 'তারিখ',
    history: 'লেনদেনের ইতিহাস',
    exportPdf: 'পিডিএফ এক্সপোর্ট',
    settings: 'সেটিংস',
    language: 'ভাষা',
    darkMode: 'ডার্ক মোড',
    confirmDelete: 'আপনি কি নিশ্চিত যে আপনি ডিলিট করতে চান?',
    back: 'ফিরে যান',
    newDebt: 'নতুন বাকি',
    newPayment: 'জমা/পরিশোধ',
    customerDetails: 'কাস্টমার ডিটেইলস',
    allTransactions: 'সকল লেনদেন',
    statement: 'স্টেটমেন্ট',
    sl: 'ক্রমিক',
    startDate: 'শুরুর তারিখ',
    endDate: 'শেষ তারিখ',
    generateReport: 'রিপোর্ট তৈরি করুন',
    allTime: 'সব সময়ের',
    customRange: 'নির্দিষ্ট সময়',
    balance: 'ব্যালেন্স',
  }
};
