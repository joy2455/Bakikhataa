import React, { useState, useMemo } from 'react';
import { Plus, Search, Edit2, Trash2, ChevronLeft, Download, Settings as SettingsIcon, Moon, Sun, Languages, ArrowUpCircle, ArrowDownCircle } from 'lucide-react';
import { format } from 'date-fns';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { useLocalStorage } from './hooks/useLocalStorage';
import { TRANSLATIONS, Customer, Transaction } from './types';
import { cn } from './lib/utils';

export default function App() {
  const {
    customers,
    settings,
    addCustomer,
    updateCustomer,
    deleteCustomer,
    addTransaction,
    updateTransaction,
    deleteTransaction,
    toggleLanguage,
    toggleDarkMode,
  } = useLocalStorage();

  const [view, setView] = useState<'dashboard' | 'customer-details' | 'settings'>('dashboard');
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalType, setModalType] = useState<'add-customer' | 'edit-customer' | 'add-transaction' | 'edit-transaction' | 'confirm-delete-customer' | 'confirm-delete-transaction' | 'export-pdf'>('add-customer');
  const [editingItem, setEditingItem] = useState<any>(null);

  const t = TRANSLATIONS[settings.language];

  const totalDebt = useMemo(() => {
    return customers.reduce((acc, customer) => {
      return acc + customer.transactions.reduce((cAcc, t) => {
        return t.type === 'debt' ? cAcc + t.amount : cAcc - t.amount;
      }, 0);
    }, 0);
  }, [customers]);

  const filteredCustomers = useMemo(() => {
    return customers.filter(c => 
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.address.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [customers, searchQuery]);

  const selectedCustomer = useMemo(() => {
    return customers.find(c => c.id === selectedCustomerId);
  }, [customers, selectedCustomerId]);

  const transactionsWithBalance = useMemo(() => {
    if (!selectedCustomer) return [];
    let balance = 0;
    return [...selectedCustomer.transactions]
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .map(t => {
        balance += t.type === 'debt' ? t.amount : -t.amount;
        return { ...t, runningBalance: balance };
      })
      .reverse();
  }, [selectedCustomer]);

  const getCustomerBalance = (customer: Customer) => {
    return customer.transactions.reduce((acc, t) => {
      return t.type === 'debt' ? acc + t.amount : acc - t.amount;
    }, 0);
  };

  const handleExportPDF = (customer?: Customer, startDate?: string, endDate?: string) => {
    const doc = new jsPDF() as any;
    const title = customer ? `${customer.name} - ${t.statement}` : `${t.appName} - ${t.allTransactions}`;
    
    doc.setFontSize(18);
    doc.text(title, 14, 22);

    if (startDate && endDate) {
      doc.setFontSize(10);
      doc.text(`${t.date}: ${format(new Date(startDate), 'dd/MM/yyyy')} - ${format(new Date(endDate), 'dd/MM/yyyy')}`, 14, 28);
    }
    
    let filteredTransactions = customer 
      ? customer.transactions 
      : customers.flatMap(c => c.transactions.map(tr => ({ ...tr, customerName: c.name })));

    if (startDate && endDate) {
      const start = new Date(startDate);
      const end = new Date(endDate);
      end.setHours(23, 59, 59, 999);
      filteredTransactions = (filteredTransactions as any[]).filter(t => {
        const d = new Date(t.date);
        return d >= start && d <= end;
      });
    }

    let runningBalance = 0;
    const sortedTransactions = [...filteredTransactions].sort((a: any, b: any) => 
      new Date(a.date).getTime() - new Date(b.date).getTime()
    );

    const tableData = sortedTransactions.map((t: any, index) => {
      runningBalance += t.type === 'debt' ? t.amount : -t.amount;
      const row = [
        customer ? index + 1 : t.customerName,
        format(new Date(t.date), 'dd/MM/yyyy'),
        t.description,
        t.type === 'debt' ? `৳ ${t.amount}` : '-',
        t.type === 'payment' ? `৳ ${t.amount}` : '-',
      ];
      if (customer) row.push(`৳ ${runningBalance}`);
      return row;
    });

    const headers = customer 
      ? [[t.sl, t.date, t.description, t.newDebt, t.newPayment, t.balance]]
      : [['Customer', t.date, t.description, t.newDebt, t.newPayment]];

    autoTable(doc, {
      startY: startDate && endDate ? 35 : 30,
      head: headers,
      body: tableData,
      theme: 'grid',
      headStyles: { fillColor: [37, 99, 235] },
    });

    if (customer) {
      const finalY = (doc as any).lastAutoTable.finalY;
      const balance = (filteredTransactions as Transaction[]).reduce((acc, t) => {
        return t.type === 'debt' ? acc + t.amount : acc - t.amount;
      }, 0);
      doc.text(`${t.totalDebt}: ৳ ${balance}`, 14, finalY + 10);
    }

    doc.save(`${title.replace(/\s+/g, '_')}.pdf`);
  };

  const Modal = () => {
    const [name, setName] = useState(editingItem?.name || '');
    const [address, setAddress] = useState(editingItem?.address || '');
    const [amount, setAmount] = useState(editingItem?.amount?.toString() || '');
    const [description, setDescription] = useState(editingItem?.description || '');
    const [type, setType] = useState<'debt' | 'payment'>(editingItem?.type || 'debt');
    const [startDate, setStartDate] = useState(format(new Date(), 'yyyy-MM-01'));
    const [endDate, setEndDate] = useState(format(new Date(), 'yyyy-MM-dd'));
    const [isCustomRange, setIsCustomRange] = useState(false);

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (modalType === 'add-customer') {
        addCustomer(name, address);
      } else if (modalType === 'edit-customer') {
        updateCustomer(editingItem.id, name, address);
      } else if (modalType === 'add-transaction') {
        addTransaction(selectedCustomerId!, parseFloat(amount), description, type);
      } else if (modalType === 'edit-transaction') {
        updateTransaction(selectedCustomerId!, editingItem.id, parseFloat(amount), description);
      } else if (modalType === 'confirm-delete-customer') {
        deleteCustomer(selectedCustomerId!);
        setView('dashboard');
      } else if (modalType === 'confirm-delete-transaction') {
        deleteTransaction(selectedCustomerId!, editingItem.id);
      } else if (modalType === 'export-pdf') {
        handleExportPDF(editingItem, isCustomRange ? startDate : undefined, isCustomRange ? endDate : undefined);
      }
      setIsModalOpen(false);
      setEditingItem(null);
    };

    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50 backdrop-blur-sm transition-all duration-300">
        <div className="bg-card text-card-foreground rounded-2xl p-6 w-full max-w-md shadow-xl border border-border transition-colors duration-300">
          <h2 className="text-xl font-bold mb-4">
            {modalType === 'add-customer' && t.addCustomer}
            {modalType === 'edit-customer' && t.edit}
            {modalType === 'add-transaction' && t.addTransaction}
            {modalType === 'edit-transaction' && t.edit}
            {modalType === 'export-pdf' && t.exportPdf}
            {(modalType === 'confirm-delete-customer' || modalType === 'confirm-delete-transaction') && t.delete}
          </h2>
          {modalType === 'export-pdf' ? (
            <div className="space-y-4">
              <div className="flex gap-2">
                <button
                  onClick={() => setIsCustomRange(false)}
                  className={cn(
                    "flex-1 py-2 rounded-lg border",
                    !isCustomRange ? "bg-blue-600 text-white border-blue-600" : "bg-transparent"
                  )}
                >
                  {t.allTime}
                </button>
                <button
                  onClick={() => setIsCustomRange(true)}
                  className={cn(
                    "flex-1 py-2 rounded-lg border",
                    isCustomRange ? "bg-blue-600 text-white border-blue-600" : "bg-transparent"
                  )}
                >
                  {t.customRange}
                </button>
              </div>
              {isCustomRange && (
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-zinc-500 mb-1">{t.startDate}</label>
                    <input 
                      type="date"
                      className="w-full p-2 rounded-lg border border-border bg-background text-foreground transition-colors duration-300"
                      value={startDate}
                      onChange={e => setStartDate(e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-zinc-500 mb-1">{t.endDate}</label>
                    <input 
                      type="date"
                      className="w-full p-2 rounded-lg border border-border bg-background text-foreground transition-colors duration-300"
                      value={endDate}
                      onChange={e => setEndDate(e.target.value)}
                    />
                  </div>
                </div>
              )}
              <div className="flex gap-2 pt-2">
                <button 
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 py-2 rounded-lg bg-muted font-medium transition-colors"
                >
                  {t.cancel}
                </button>
                <button 
                  onClick={handleSubmit}
                  className="flex-1 py-2 rounded-lg bg-blue-600 text-white font-medium flex items-center justify-center gap-2"
                >
                  <Download className="w-4 h-4" /> {t.generateReport}
                </button>
              </div>
            </div>
          ) : modalType.startsWith('confirm-delete') ? (
            <div className="space-y-4">
              <p className="text-zinc-600 dark:text-zinc-400">{t.confirmDelete}</p>
              <div className="flex gap-2 pt-2">
                <button 
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 py-2 rounded-lg bg-muted font-medium transition-colors"
                >
                  {t.cancel}
                </button>
                <button 
                  type="button"
                  onClick={handleSubmit}
                  className="flex-1 py-2 rounded-lg bg-red-600 text-white font-medium"
                >
                  {t.delete}
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
            {(modalType === 'add-customer' || modalType === 'edit-customer') && (
              <>
                <div>
                  <label className="block text-sm font-medium mb-1">{t.customerName}</label>
                  <input 
                    autoFocus
                    required
                    className="w-full p-2 rounded-lg border border-border bg-background text-foreground transition-colors duration-300"
                    value={name}
                    onChange={e => setName(e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">{t.address}</label>
                  <input 
                    required
                    className="w-full p-2 rounded-lg border border-border bg-background text-foreground transition-colors duration-300"
                    value={address}
                    onChange={e => setAddress(e.target.value)}
                  />
                </div>
              </>
            )}
            {(modalType === 'add-transaction' || modalType === 'edit-transaction') && (
              <>
                {modalType === 'add-transaction' && (
                  <div className="flex gap-2 mb-4">
                    <button
                      type="button"
                      onClick={() => setType('debt')}
                      className={cn(
                        "flex-1 py-2 rounded-lg border transition-all",
                        type === 'debt' ? "bg-red-500 text-white border-red-500" : "bg-transparent"
                      )}
                    >
                      {t.newDebt}
                    </button>
                    <button
                      type="button"
                      onClick={() => setType('payment')}
                      className={cn(
                        "flex-1 py-2 rounded-lg border transition-all",
                        type === 'payment' ? "bg-green-500 text-white border-green-500" : "bg-transparent"
                      )}
                    >
                      {t.newPayment}
                    </button>
                  </div>
                )}
                <div>
                  <label className="block text-sm font-medium mb-1">{t.amount}</label>
                  <input 
                    autoFocus
                    required
                    type="number"
                    className="w-full p-2 rounded-lg border border-border bg-background text-foreground transition-colors duration-300"
                    value={amount}
                    onChange={e => setAmount(e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">{t.description}</label>
                  <input 
                    required
                    className="w-full p-2 rounded-lg border border-border bg-background text-foreground transition-colors duration-300"
                    value={description}
                    onChange={e => setDescription(e.target.value)}
                  />
                </div>
              </>
            )}
            <div className="flex gap-2 pt-2">
              <button 
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="flex-1 py-2 rounded-lg bg-muted font-medium transition-colors"
              >
                {t.cancel}
              </button>
              <button 
                type="submit"
                className="flex-1 py-2 rounded-lg bg-blue-600 text-white font-medium"
              >
                {t.save}
              </button>
            </div>
          </form>
        )}
        </div>
      </div>
    );
  };

  return (
    <div className={cn("min-h-screen bg-background text-foreground font-sans transition-colors duration-300")}>
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-md border-b border-border px-4 py-3 flex items-center justify-between transition-colors duration-300">
        <div className="flex items-center gap-2">
          {view !== 'dashboard' && (
            <button onClick={() => setView('dashboard')} className="p-1 -ml-1">
              <ChevronLeft className="w-6 h-6" />
            </button>
          )}
          <h1 className="text-xl font-bold tracking-tight">
            {view === 'dashboard' ? t.appName : view === 'customer-details' ? t.customerDetails : t.settings}
          </h1>
        </div>
        <div className="flex items-center gap-3">
          <button onClick={() => setView('settings')} className="p-2 rounded-full hover:bg-muted transition-colors">
            <SettingsIcon className="w-5 h-5" />
          </button>
        </div>
      </header>

      <main className="p-4 max-w-2xl mx-auto pb-24">
        {view === 'dashboard' && (
          <div className="space-y-6">
            {/* Summary Card */}
            <div className="bg-blue-600 rounded-3xl p-6 text-white shadow-lg shadow-blue-500/20">
              <p className="text-blue-100 text-sm font-medium uppercase tracking-wider mb-1">{t.totalDebt}</p>
              <h2 className="text-4xl font-black">৳ {totalDebt.toLocaleString()}</h2>
            </div>

            {/* Search and Actions */}
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
                <input 
                  placeholder={t.search}
                  className="w-full pl-10 pr-4 py-3 rounded-2xl bg-card text-card-foreground border border-border focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all duration-300"
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                />
              </div>
              <button 
                onClick={() => {
                  setEditingItem(null);
                  setModalType('export-pdf');
                  setIsModalOpen(true);
                }}
                className="p-3 rounded-2xl bg-card text-card-foreground border border-border transition-colors duration-300"
              >
                <Download className="w-5 h-5" />
              </button>
            </div>

            {/* Customer List */}
            <div className="space-y-3">
              {filteredCustomers.length === 0 ? (
                <div className="text-center py-12 text-zinc-500">{t.noCustomers}</div>
              ) : (
                filteredCustomers.map(customer => {
                  const balance = getCustomerBalance(customer);
                  return (
                    <div 
                      key={customer.id}
                      onClick={() => {
                        setSelectedCustomerId(customer.id);
                        setView('customer-details');
                      }}
                      className="bg-card text-card-foreground p-4 rounded-2xl border border-border flex items-center justify-between cursor-pointer active:scale-[0.98] transition-all duration-300"
                    >
                      <div>
                        <h3 className="font-bold text-lg">{customer.name}</h3>
                        <p className="text-sm text-zinc-500">{customer.address}</p>
                      </div>
                      <div className="text-right">
                        <p className={cn("font-black text-lg", balance > 0 ? "text-red-500" : "text-green-500")}>
                          ৳ {Math.abs(balance).toLocaleString()}
                        </p>
                        <p className="text-[10px] uppercase font-bold opacity-50">
                          {balance > 0 ? t.newDebt : t.newPayment}
                        </p>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}

        {view === 'customer-details' && selectedCustomer && (
          <div className="space-y-6">
            <div className="bg-card text-card-foreground p-6 rounded-3xl border border-border transition-colors duration-300">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h2 className="text-2xl font-bold">{selectedCustomer.name}</h2>
                  <p className="text-zinc-500">{selectedCustomer.address}</p>
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={() => {
                      setEditingItem(selectedCustomer);
                      setModalType('edit-customer');
                      setIsModalOpen(true);
                    }}
                    className="p-2 rounded-full bg-muted transition-colors"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={() => {
                      setModalType('confirm-delete-customer');
                      setIsModalOpen(true);
                    }}
                    className="p-2 rounded-full bg-red-100 dark:bg-red-900/30 text-red-600"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
              <div className="pt-4 border-t border-zinc-100 dark:border-zinc-800 flex justify-between items-center">
                <span className="text-sm font-medium text-zinc-500">{t.totalDebt}</span>
                <span className={cn("text-2xl font-black", getCustomerBalance(selectedCustomer) > 0 ? "text-red-500" : "text-green-500")}>
                  ৳ {getCustomerBalance(selectedCustomer).toLocaleString()}
                </span>
              </div>
            </div>

            <div className="flex gap-2">
              <button 
                onClick={() => {
                  setModalType('add-transaction');
                  setIsModalOpen(true);
                }}
                className="flex-1 bg-blue-600 text-white py-3 rounded-2xl font-bold flex items-center justify-center gap-2"
              >
                <Plus className="w-5 h-5" /> {t.addTransaction}
              </button>
              <button 
                onClick={() => {
                  setEditingItem(selectedCustomer);
                  setModalType('export-pdf');
                  setIsModalOpen(true);
                }}
                className="p-3 rounded-2xl bg-card text-card-foreground border border-border transition-colors duration-300"
              >
                <Download className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              <h3 className="font-bold text-sm uppercase tracking-wider text-zinc-500 px-1">{t.history}</h3>
              {transactionsWithBalance.map(transaction => (
                <div 
                  key={transaction.id}
                  className="bg-card text-card-foreground p-4 rounded-2xl border border-border flex items-center justify-between transition-colors duration-300"
                >
                  <div className="flex items-center gap-3">
                    <div className={cn(
                      "p-2 rounded-full",
                      transaction.type === 'debt' ? "bg-red-100 dark:bg-red-900/30 text-red-600" : "bg-green-100 dark:bg-green-900/30 text-green-600"
                    )}>
                      {transaction.type === 'debt' ? <ArrowUpCircle className="w-5 h-5" /> : <ArrowDownCircle className="w-5 h-5" />}
                    </div>
                    <div>
                      <p className="font-bold">{transaction.description}</p>
                      <div className="flex items-center gap-2">
                        <p className="text-xs text-zinc-500">{format(new Date(transaction.date), 'dd/MM/yyyy')}</p>
                        <span className="text-[10px] text-zinc-300 dark:text-zinc-700">•</span>
                        <p className="text-xs font-medium text-zinc-400">
                          {t.balance}: ৳ {transaction.runningBalance.toLocaleString()}
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <p className={cn("font-bold text-lg", transaction.type === 'debt' ? "text-red-500" : "text-green-500")}>
                      {transaction.type === 'debt' ? '+' : '-'}৳ {transaction.amount.toLocaleString()}
                    </p>
                    <div className="flex gap-1">
                      <button 
                        onClick={() => {
                          setEditingItem(transaction);
                          setModalType('edit-transaction');
                          setIsModalOpen(true);
                        }}
                        className="p-1 text-zinc-400"
                      >
                        <Edit2 className="w-3 h-3" />
                      </button>
                      <button 
                        onClick={() => {
                          setEditingItem(transaction);
                          setModalType('confirm-delete-transaction');
                          setIsModalOpen(true);
                        }}
                        className="p-1 text-red-400"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {view === 'settings' && (
          <div className="space-y-4">
            <div className="bg-card text-card-foreground rounded-3xl border border-border overflow-hidden transition-colors duration-300">
              <button 
                onClick={toggleLanguage}
                className="w-full p-5 flex items-center justify-between hover:bg-muted/50 transition-colors"
              >
                <div className="flex items-center gap-4">
                  <div className="p-2 rounded-xl bg-blue-100 dark:bg-blue-900/30 text-blue-600">
                    <Languages className="w-5 h-5" />
                  </div>
                  <div className="text-left">
                    <p className="font-bold">{t.language}</p>
                    <p className="text-xs text-zinc-500">{settings.language === 'en' ? 'English' : 'বাংলা'}</p>
                  </div>
                </div>
                <div className="w-12 h-6 bg-zinc-200 dark:bg-zinc-700 rounded-full relative">
                  <div className={cn(
                    "absolute top-1 w-4 h-4 bg-white rounded-full transition-all",
                    settings.language === 'en' ? "left-1" : "left-7"
                  )} />
                </div>
              </button>

              <div className="h-px bg-zinc-100 dark:bg-zinc-800 mx-5" />

              <button 
                onClick={toggleDarkMode}
                className="w-full p-5 flex items-center justify-between hover:bg-muted/50 transition-colors"
              >
                <div className="flex items-center gap-4">
                  <div className="p-2 rounded-xl bg-purple-100 dark:bg-purple-900/30 text-purple-600">
                    {settings.darkMode ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
                  </div>
                  <div className="text-left">
                    <p className="font-bold">{t.darkMode}</p>
                    <p className="text-xs text-zinc-500">{settings.darkMode ? 'On' : 'Off'}</p>
                  </div>
                </div>
                <div className={cn(
                  "w-12 h-6 rounded-full relative transition-colors",
                  settings.darkMode ? "bg-blue-600" : "bg-muted"
                )}>
                  <div className={cn(
                    "absolute top-1 w-4 h-4 bg-white rounded-full transition-all",
                    settings.darkMode ? "left-7" : "left-1"
                  )} />
                </div>
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Floating Action Button */}
      {view === 'dashboard' && (
        <button 
          onClick={() => {
            setModalType('add-customer');
            setEditingItem(null);
            setIsModalOpen(true);
          }}
          className="fixed bottom-8 right-8 w-16 h-16 bg-blue-600 text-white rounded-full shadow-2xl shadow-blue-500/40 flex items-center justify-center active:scale-90 transition-transform z-40"
        >
          <Plus className="w-8 h-8" />
        </button>
      )}

      {isModalOpen && <Modal />}
    </div>
  );
}
