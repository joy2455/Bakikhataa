# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Initial release of Baki Khata.
- Customer management (Add, Edit, Delete).
- Transaction tracking (Debt, Payment).
- Multi-language support (English, Bengali).
- Dark mode support.
- PDF export for statements and reports.
- GitHub working directory structure (CI, templates, docs).
