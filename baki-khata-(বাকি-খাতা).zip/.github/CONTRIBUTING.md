# Contributing to Baki Khata

Thanks for taking the time to contribute to Baki Khata!

## How to Contribute

1.  **Fork the repository** on GitHub.
2.  **Clone your fork** to your local machine.
3.  **Create a new branch** for your feature or bug fix.
4.  **Make your changes** and commit them.
5.  **Push your changes** to your fork.
6.  **Create a pull request** from your fork to the main repository.

## Code Style

-   Use **TypeScript** for all code.
-   Follow the **Tailwind CSS** utility classes for styling.
-   Use **Lucide React** for icons.
-   Ensure your code is well-documented and easy to understand.

## Reporting Bugs

-   Use the **Bug report** template on GitHub.
-   Provide as much detail as possible, including reproduction steps and log output.

## Suggesting Features

-   Use the **Feature request** template on GitHub.
-   Describe the problem you're trying to solve and your proposed solution.

## License

By contributing to Baki Khata, you agree that your contributions will be licensed under the **MIT License**.
