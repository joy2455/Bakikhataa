# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 1.0.x   | :white_check_mark: |
| < 1.0   | :x:                |

## Reporting a Vulnerability

If you find a security vulnerability, please report it to us by emailing **javedgaibandha@gmail.com**.

We will respond to your report within 48 hours and provide a fix as soon as possible.
